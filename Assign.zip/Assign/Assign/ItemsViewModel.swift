//
//  ItemsViewModel.swift
//  Assignment
//
//  Created by Sagar Kale on 28/05/24.
//

import Foundation
import Combine

class ItemsViewModel: ObservableObject {
    
    @Published var items: [Item] = []
    @Published var errorMessage: String?
    private var cancellables = Set<AnyCancellable>()
    
    func fetchItems() {
        
        APIService.shared.fetchItems()
            .sink(receiveCompletion:  { completion in
                switch completion {
                case .failure(let error):
                    print("Error fetching items:  \(error)")
                case .finished:
                    break
                }
                
            }, receiveValue: { [weak self ] items in
                self?.items = items
                
            })
            .store(in: &cancellables)
    }
}
