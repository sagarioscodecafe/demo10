//
//  AssignUITests.swift
//  AssignUITests
//
//  Created by Sagar Kale on 30/05/24.
//

import XCTest

final class AssignUITests: XCTestCase {
    
    func testItemsView() {
        
        let app = XCUIApplication()
        app.launch()
        
        let list = app.tables["ItemList"]
        
        XCTAssertTrue(list.waitForExistence(timeout: 5))
        XCTAssertGreaterThan(list.cells.count, 0)
    }

}
