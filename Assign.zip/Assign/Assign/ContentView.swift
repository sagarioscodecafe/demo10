//
//  ContentView.swift
//  Assign
//
//  Created by Sagar Kale on 30/05/24.
//


import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = ItemsViewModel()
    
    var body: some View {
        
       
        NavigationView {
            List(viewModel.items) { item in
                Text(item.body)
            }
            .navigationTitle("Items")
            .onAppear{
                viewModel.fetchItems()
            }
        }
    }
}

struct ItemsView_Previews: PreviewProvider {
    
    static var previews: some View {
        ContentView()
    }
}
