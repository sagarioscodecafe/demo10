//
//  APIService.swift
//  Assignment
//
//  Created by Sagar Kale on 28/05/24.
//

import Foundation
import Combine

enum APIError: Error {
    case invalidURL
    case decodingError
}

class APIService {
    static let shared = APIService()
    private init() {}
    
    func fetchItems() -> AnyPublisher <[Item], Error> {
        
        guard    let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else {
            return Fail(error: APIError.invalidURL).eraseToAnyPublisher()
        }
        
        return URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data)
            .decode(type: [Item].self, decoder: JSONDecoder())
            .mapError { error in
                error is DecodingError ? APIError.decodingError : error
            }
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
}
