//
//  ResponseModel.swift
//  Assignment
//
//  Created by Sagar Kale on 28/05/24.
//

import Foundation

struct Item: Codable, Identifiable {
    
    let id: Int
    let body: String
}

