//
//  AssignTests.swift
//  AssignTests
//
//  Created by Sagar Kale on 30/05/24.
//

import XCTest
import Combine
@testable import Assign

final class AssignTests: XCTestCase {
    
    var cancellables: Set<AnyCancellable>!
    
    override func setUp()  {
        super.setUp()
        cancellables = []
    }
    
    override func tearDown() {
        cancellables = nil
        super.tearDown()
    }
    
    func testFetchItemsSuccess(){
        
        let  expectation = XCTestExpectation(description: "Fetch items")
        APIService.shared.fetchItems()
            .sink(receiveCompletion: { completion in
                
                if case .failure(let error ) = completion {
                    
                    XCTFail("Error: \(error)")
                }
            }, receiveValue: { items in
                XCTAssertGreaterThan(items.count, 0)
                expectation.fulfill()
            }).store(in: &cancellables)
        wait(for: [expectation], timeout: 5)
    }
    
//    func testFetchItemsInvalidURL() {
//        
//        let expectation = XCTestExpectation(description: "Invalid URL")
//        APIService.shared.fetchItems()
//            .sink(receiveCompletion: { completion  in
//                if case .failure(let error ) = completion {
//                    XCTAssertEqual(error as? APIError, APIError.invalidURL)
//                    expectation.fulfill()
//                }
//            }, receiveValue: { _ in
//                XCTFail("Should not receive value")
//            })
//            .store(in: &cancellables)
//        wait(for: [expectation],timeout: 5)
//
//    }
    
    func testFetchItems() {
        let expectation = XCTestExpectation(description: "Fetch Items")
        let apiService = APIService.shared
        apiService.fetchItems()
            .sink(receiveCompletion: {completion in
                if case .failure(let error) = completion  {
                    
                    XCTFail("Error: \(error)")
                }
            }, receiveValue: { items in
                XCTAssertGreaterThan(items.count, 0)
                expectation.fulfill()
                
            })
            .store(in: &cancellables)
        wait(for: [expectation],timeout: 5)
        
    }
    
    func testViewModelFetchItems() {
        
        let viewModel = ItemsViewModel()
        let expectation = XCTestExpectation(description: "Fetch Items")
        
        viewModel.$items
            .dropFirst()
            .sink{ items in
                
                XCTAssertGreaterThan(items.count, 0)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        viewModel.fetchItems()
        wait(for: [expectation], timeout: 5)
        
    }
}
